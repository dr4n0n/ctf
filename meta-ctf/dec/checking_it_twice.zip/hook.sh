#!/bin/bash
rm hook.sh
node app.js